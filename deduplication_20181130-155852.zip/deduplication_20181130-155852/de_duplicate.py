import pandas as pd
import time
import json


def read_file(input_file: str) -> None:
    """
    To read input file and find duplicates
    :param input_file: input file to be read
    :return: None
    """
    # time calculated when code has started to run
    start = time.time()

    # dictionary to hold unique ids
    dict_name = {}
    # initialize list of ids
    lst_ids = []

    # read input file into data frame
    df = pd.read_csv(input_file)

    # set if record is duplicate or not based on name and birthdate combination
    # assign the results to a new column in the data frame
    df["is_duplicate"] = df.duplicated(subset=['name', 'birthdate'], keep=False)

    # iterate over data frame rows
    for index, row in df.iterrows():
        # name_date value for checking for duplicates
        name_date = "{}_{}".format(row['name'], row['birthdate'])

        # check if row is duplicate
        if row["is_duplicate"]:
            # check if name_date is already in dict.keys
            if name_date in dict_name.keys():
                # if already in dict.keys, increment count
                dict_name[name_date] += 1
            else:
                # else set value to 1
                dict_name[name_date] = 1

            # if is duplicate, append record id to list
            lst_ids.append(row["record_id"])
        else:
            # if not duplicate set value to 1
            dict_name[name_date] = 1

    # time calculated after running the code
    end = time.time()

    # call to method to print results to json file
    get_result(input_file, lst_ids, len(dict_name.keys()), round(int(end - start)))


def get_result(input_file: str, ids: list, unique_ids_count: int, run_time: int) -> None:
    """
     Write duplicated results into json file
    :param input_file: input file that is read for analysis
    :param ids: list of duplicate ids
    :param unique_ids_count: count of unique ids
    :param run_time: time taken to run the code
    :return: None
    """

    # initialize dictionary to store results
    data = list()
    data.append({
        'candidate_name': "Swetha Krishnakumar",
        'candidate_email': "sweth.krishnakumar@gmail.com",
        'candidate_date': "2018-12-18",
        'data_filename': input_file,
        'number_of_unique_members': unique_ids_count,
        'wall_time_in_seconds': run_time,
        'ids_of_duplicate_records': [
            ids
        ]
    })

    # open json file to write results to
    with open('results.json', 'w') as outfile:
        # use json object to write results to file
        json.dump(data, outfile, sort_keys=False,
                  indent=4)


if __name__ == '__main__':
    # call method to read input file
    read_file("data_20181130-155852.csv")
